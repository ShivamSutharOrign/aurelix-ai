import { useState, useCallback } from "react";
import { Send, Paperclip, Mic } from "lucide-react";
import { motion } from "framer-motion";

interface ChatInputProps {
  onSend: (message: string) => void;
  placeholder?: string;
  disabled?: boolean;
}

export function ChatInput({ onSend, placeholder = "Type a message...", disabled }: ChatInputProps) {
  const [value, setValue] = useState("");

  const handleSubmit = useCallback(() => {
    if (!value.trim() || disabled) return;
    onSend(value.trim());
    setValue("");
  }, [value, disabled, onSend]);

  return (
    <div className="px-3 pb-3 pt-2">
      <div className="flex items-end gap-2 rounded-2xl border border-border bg-card px-3 py-2">
        <button className="flex items-center justify-center h-9 w-9 rounded-xl hover:bg-accent transition-colors shrink-0">
          <Paperclip className="h-4 w-4 text-muted-foreground" />
        </button>
        <textarea
          value={value}
          onChange={(e) => setValue(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              handleSubmit();
            }
          }}
          placeholder={placeholder}
          rows={1}
          className="flex-1 resize-none bg-transparent py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none max-h-28"
          disabled={disabled}
        />
        <button className="flex items-center justify-center h-9 w-9 rounded-xl hover:bg-accent transition-colors shrink-0">
          <Mic className="h-4 w-4 text-muted-foreground" />
        </button>
        <motion.button
          whileTap={{ scale: 0.92 }}
          onClick={handleSubmit}
          disabled={!value.trim() || disabled}
          className="flex items-center justify-center h-9 w-9 rounded-xl bg-foreground text-background disabled:opacity-20 transition-opacity shrink-0"
        >
          <Send className="h-4 w-4" />
        </motion.button>
      </div>
    </div>
  );
}
