export function TypingIndicator() {
  return (
    <div className="flex items-center gap-1.5 px-4 py-2.5 rounded-2xl rounded-bl-md bg-card border border-border w-fit">
      <div className="h-1.5 w-1.5 rounded-full bg-muted-foreground typing-dot" />
      <div className="h-1.5 w-1.5 rounded-full bg-muted-foreground typing-dot" />
      <div className="h-1.5 w-1.5 rounded-full bg-muted-foreground typing-dot" />
    </div>
  );
}
