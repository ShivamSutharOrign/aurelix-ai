import { useLocation, useNavigate } from "react-router-dom";
import { MessageSquare, Search, ImageIcon, Video, Mic } from "lucide-react";
import { motion } from "framer-motion";

const tabs = [
  { path: "/", icon: MessageSquare, label: "Chat" },
  { path: "/research", icon: Search, label: "Research" },
  { path: "/image", icon: ImageIcon, label: "Image" },
  { path: "/video", icon: Video, label: "Video" },
  { path: "/voice", icon: Mic, label: "Voice" },
];

export function BottomNav() {
  const location = useLocation();
  const navigate = useNavigate();

  return (
    <nav className="relative flex items-center justify-around px-2 pt-1.5 pb-1.5 safe-bottom border-t border-border bg-background">
      {tabs.map((tab) => {
        const isActive = location.pathname === tab.path;
        return (
          <button
            key={tab.path}
            onClick={() => navigate(tab.path)}
            className="relative flex flex-col items-center gap-0.5 px-4 py-1.5 rounded-xl transition-colors"
          >
            {isActive && (
              <motion.div
                layoutId="nav-pill"
                className="absolute -top-1.5 left-1/2 -translate-x-1/2 h-[2px] w-5 rounded-full bg-foreground"
                transition={{ type: "spring", stiffness: 500, damping: 35 }}
              />
            )}
            <tab.icon
              className={`h-5 w-5 transition-colors ${
                isActive ? "text-foreground" : "text-muted-foreground"
              }`}
            />
            <span
              className={`text-[9px] font-medium tracking-wide transition-colors ${
                isActive ? "text-foreground" : "text-muted-foreground"
              }`}
            >
              {tab.label}
            </span>
          </button>
        );
      })}
    </nav>
  );
}
