import { useNavigate } from "react-router-dom";
import { usePlan } from "@/contexts/PlanContext";
import { Crown } from "lucide-react";
import { motion } from "framer-motion";

interface UpgradeGateProps {
  feature: string;
  children: React.ReactNode;
}

export function UpgradeGate({ feature, children }: UpgradeGateProps) {
  const { isPro } = usePlan();
  const navigate = useNavigate();

  if (isPro) return <>{children}</>;

  return (
    <div className="flex flex-col items-center justify-center h-full gap-5 px-6">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="flex flex-col items-center gap-4 text-center"
      >
        <div className="h-14 w-14 rounded-2xl bg-accent flex items-center justify-center">
          <Crown className="h-7 w-7 text-foreground" />
        </div>
        <h2 className="font-display text-lg font-bold text-foreground">Pro Feature</h2>
        <p className="text-sm text-muted-foreground max-w-[260px]">
          {feature} is available on the Pro plan. Upgrade to unlock all features.
        </p>
        <button
          onClick={() => navigate("/upgrade")}
          className="px-6 py-3 rounded-xl bg-foreground text-background font-semibold text-sm transition-transform active:scale-[0.98]"
        >
          Upgrade to Pro — ₹199/mo
        </button>
      </motion.div>
    </div>
  );
}
