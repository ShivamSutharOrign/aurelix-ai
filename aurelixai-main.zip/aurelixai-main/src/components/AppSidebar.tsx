import { useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { X, MessageSquare, Bookmark, Settings, Plus, Trash2, Clock, Crown, Moon, Sun, Info, User } from "lucide-react";
import { usePlan } from "@/contexts/PlanContext";

interface SidebarProps {
  open: boolean;
  onClose: () => void;
  onNewChat?: () => void;
}

const chatHistory = [
  { id: "1", title: "YouTube video script ideas", time: "2 min ago" },
  { id: "2", title: "Study notes summary", time: "1 hour ago" },
  { id: "3", title: "Thumbnail design prompts", time: "Yesterday" },
  { id: "4", title: "SEO tag generator", time: "2 days ago" },
  { id: "5", title: "Blog post outline", time: "Last week" },
];

const savedPrompts = [
  "Write a YouTube script about...",
  "Summarize this article...",
  "Generate thumbnail ideas for...",
];

export function AppSidebar({ open, onClose, onNewChat }: SidebarProps) {
  const [tab, setTab] = useState<"history" | "saved" | "settings">("history");
  const [settingsView, setSettingsView] = useState<null | "account" | "appearance" | "about">(null);
  const [darkMode, setDarkMode] = useState(true);
  const navigate = useNavigate();
  const { isPro } = usePlan();

  const handleNewChat = useCallback(() => {
    onNewChat?.();
    onClose();
    navigate("/");
  }, [onNewChat, onClose, navigate]);

  const handleUpgrade = useCallback(() => {
    onClose();
    navigate("/upgrade");
  }, [onClose, navigate]);

  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.15 }}
            className="fixed inset-0 bg-background/70 backdrop-blur-sm z-40"
            onClick={onClose}
          />
          <motion.aside
            initial={{ x: "-100%" }}
            animate={{ x: 0 }}
            exit={{ x: "-100%" }}
            transition={{ type: "spring", damping: 30, stiffness: 300 }}
            className="fixed left-0 top-0 bottom-0 w-[280px] z-50 bg-card border-r border-border flex flex-col"
          >
            <div className="flex items-center justify-between p-4 border-b border-border">
              <div className="flex items-center gap-2">
                <h2 className="font-display font-bold text-foreground">Aurelix AI</h2>
                {isPro && (
                  <span className="text-[9px] font-semibold bg-foreground text-background px-1.5 py-0.5 rounded-full flex items-center gap-0.5">
                    <Crown className="h-2.5 w-2.5" /> PRO
                  </span>
                )}
              </div>
              <button onClick={onClose} className="h-8 w-8 rounded-lg flex items-center justify-center hover:bg-accent transition-colors">
                <X className="h-4 w-4 text-muted-foreground" />
              </button>
            </div>

            <div className="px-3 py-3">
              <button
                onClick={handleNewChat}
                className="w-full flex items-center gap-2 px-4 py-2.5 rounded-xl border border-border text-foreground text-sm font-medium hover:bg-accent transition-colors"
              >
                <Plus className="h-4 w-4" />
                New Chat
              </button>
            </div>

            <div className="flex px-3 gap-1">
              {([
                { key: "history", icon: Clock, label: "History" },
                { key: "saved", icon: Bookmark, label: "Saved" },
                { key: "settings", icon: Settings, label: "Settings" },
              ] as const).map((t) => (
                <button
                  key={t.key}
                  onClick={() => { setTab(t.key); setSettingsView(null); }}
                  className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-medium transition-colors ${
                    tab === t.key
                      ? "bg-accent text-foreground"
                      : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  <t.icon className="h-3.5 w-3.5" />
                  {t.label}
                </button>
              ))}
            </div>

            <div className="flex-1 overflow-y-auto px-3 py-3 no-scrollbar">
              {tab === "history" && (
                <div className="space-y-0.5">
                  {chatHistory.map((chat) => (
                    <button
                      key={chat.id}
                      className="w-full flex items-start gap-3 p-3 rounded-xl hover:bg-accent transition-colors text-left group"
                    >
                      <MessageSquare className="h-4 w-4 text-muted-foreground mt-0.5 shrink-0" />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm text-foreground truncate">{chat.title}</p>
                        <p className="text-[10px] text-muted-foreground">{chat.time}</p>
                      </div>
                      <Trash2 className="h-3.5 w-3.5 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity mt-0.5" />
                    </button>
                  ))}
                </div>
              )}

              {tab === "saved" && (
                <div className="space-y-2">
                  {savedPrompts.map((prompt, i) => (
                    <div key={i} className="p-3 rounded-xl bg-accent border border-border">
                      <p className="text-sm text-foreground">{prompt}</p>
                    </div>
                  ))}
                </div>
              )}

              {tab === "settings" && !settingsView && (
                <div className="space-y-1 pt-2">
                  <button onClick={() => setSettingsView("account")} className="w-full text-left px-3 py-2.5 rounded-xl hover:bg-accent text-sm text-foreground transition-colors flex items-center gap-2.5">
                    <User className="h-4 w-4 text-muted-foreground" /> Account
                  </button>
                  <button onClick={() => setSettingsView("appearance")} className="w-full text-left px-3 py-2.5 rounded-xl hover:bg-accent text-sm text-foreground transition-colors flex items-center gap-2.5">
                    <Moon className="h-4 w-4 text-muted-foreground" /> Appearance
                  </button>
                  <button onClick={() => setSettingsView("about")} className="w-full text-left px-3 py-2.5 rounded-xl hover:bg-accent text-sm text-foreground transition-colors flex items-center gap-2.5">
                    <Info className="h-4 w-4 text-muted-foreground" /> About
                  </button>
                  {!isPro && (
                    <button onClick={handleUpgrade} className="w-full text-left px-3 py-2.5 rounded-xl hover:bg-accent text-sm text-foreground transition-colors flex items-center gap-2.5">
                      <Crown className="h-4 w-4 text-muted-foreground" /> Upgrade to Pro
                    </button>
                  )}
                </div>
              )}

              {tab === "settings" && settingsView === "account" && (
                <div className="space-y-4 pt-2">
                  <button onClick={() => setSettingsView(null)} className="text-xs text-muted-foreground hover:text-foreground">← Back</button>
                  <div className="p-4 rounded-xl border border-border bg-accent/50 space-y-3">
                    <div className="h-12 w-12 rounded-full bg-foreground/10 flex items-center justify-center mx-auto">
                      <User className="h-6 w-6 text-foreground" />
                    </div>
                    <div className="text-center">
                      <p className="text-sm font-medium text-foreground">Guest User</p>
                      <p className="text-xs text-muted-foreground">Plan: {isPro ? "Pro" : "Free"}</p>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground text-center">Sign in to sync your data across devices</p>
                </div>
              )}

              {tab === "settings" && settingsView === "appearance" && (
                <div className="space-y-4 pt-2">
                  <button onClick={() => setSettingsView(null)} className="text-xs text-muted-foreground hover:text-foreground">← Back</button>
                  <div className="p-4 rounded-xl border border-border space-y-3">
                    <p className="text-sm font-medium text-foreground">Theme</p>
                    <div className="flex gap-2">
                      <button
                        onClick={() => setDarkMode(true)}
                        className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl border text-sm font-medium transition-colors ${darkMode ? "border-foreground/30 bg-accent text-foreground" : "border-border text-muted-foreground"}`}
                      >
                        <Moon className="h-4 w-4" /> Dark
                      </button>
                      <button
                        onClick={() => setDarkMode(false)}
                        className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl border text-sm font-medium transition-colors ${!darkMode ? "border-foreground/30 bg-accent text-foreground" : "border-border text-muted-foreground"}`}
                      >
                        <Sun className="h-4 w-4" /> Light
                      </button>
                    </div>
                    <p className="text-[10px] text-muted-foreground">Light mode coming soon</p>
                  </div>
                </div>
              )}

              {tab === "settings" && settingsView === "about" && (
                <div className="space-y-4 pt-2">
                  <button onClick={() => setSettingsView(null)} className="text-xs text-muted-foreground hover:text-foreground">← Back</button>
                  <div className="p-4 rounded-xl border border-border space-y-3 text-center">
                    <h3 className="font-display text-lg font-bold text-foreground">Aurelix AI</h3>
                    <p className="text-xs text-muted-foreground">Version 1.0.0</p>
                    <p className="text-xs text-muted-foreground leading-relaxed">
                      Your all-in-one AI assistant for content creation. Chat, research, generate images, videos, and voice — all in one place.
                    </p>
                    <div className="pt-2 border-t border-border">
                      <p className="text-[10px] text-muted-foreground">Made with ❤️ by Shivam</p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </motion.aside>
        </>
      )}
    </AnimatePresence>
  );
}
