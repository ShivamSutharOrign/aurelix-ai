import { lazy, Suspense } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AppLayout } from "@/components/AppLayout";
import { PlanProvider } from "@/contexts/PlanContext";
import ChatScreen from "@/pages/ChatScreen";
import NotFound from "./pages/NotFound";

const ResearchScreen = lazy(() => import("@/pages/ResearchScreen"));
const ImageScreen = lazy(() => import("@/pages/ImageScreen"));
const VideoScreen = lazy(() => import("@/pages/VideoScreen"));
const VoiceScreen = lazy(() => import("@/pages/VoiceScreen"));
const UpgradeScreen = lazy(() => import("@/pages/UpgradeScreen"));

const queryClient = new QueryClient();

function LazyFallback() {
  return <div className="flex-1 flex items-center justify-center"><div className="h-5 w-5 border-2 border-foreground/20 border-t-foreground rounded-full animate-spin" /></div>;
}

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <PlanProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            <Route element={<AppLayout />}>
              <Route path="/" element={<ChatScreen />} />
              <Route path="/research" element={<Suspense fallback={<LazyFallback />}><ResearchScreen /></Suspense>} />
              <Route path="/image" element={<Suspense fallback={<LazyFallback />}><ImageScreen /></Suspense>} />
              <Route path="/video" element={<Suspense fallback={<LazyFallback />}><VideoScreen /></Suspense>} />
              <Route path="/voice" element={<Suspense fallback={<LazyFallback />}><VoiceScreen /></Suspense>} />
              <Route path="/upgrade" element={<Suspense fallback={<LazyFallback />}><UpgradeScreen /></Suspense>} />
            </Route>
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </PlanProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
