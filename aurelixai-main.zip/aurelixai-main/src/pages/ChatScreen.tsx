import { useState, useRef, useEffect, useCallback } from "react";
import { useOutletContext, useNavigate } from "react-router-dom";
import { ChatInput } from "@/components/ChatInput";
import { TypingIndicator } from "@/components/TypingIndicator";
import { motion } from "framer-motion";
import { Bot, User, Menu, Copy, Bookmark, Check, Sparkles, FileText, Youtube, BookOpen, Lightbulb } from "lucide-react";
import { usePlan } from "@/contexts/PlanContext";
import { toast } from "sonner";
import { streamChat, type ChatMessage } from "@/lib/chatService";

type AIModel = "gemini" | "chatgpt";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  model: AIModel;
  saved?: boolean;
  copied?: boolean;
}

const suggestions = [
  { icon: Youtube, label: "YouTube Script", prompt: "Write a YouTube video script about..." },
  { icon: Lightbulb, label: "Thumbnail Ideas", prompt: "Generate thumbnail ideas for..." },
  { icon: BookOpen, label: "Study Notes", prompt: "Summarize these study notes..." },
  { icon: FileText, label: "Blog Post", prompt: "Write a blog post about..." },
];

export default function ChatScreen() {
  const { openSidebar } = useOutletContext<{ openSidebar: () => void }>();
  const navigate = useNavigate();
  const { isPro } = usePlan();
  const [model, setModel] = useState<AIModel>("gemini");
  const [messages, setMessages] = useState<Message[]>([]);
  const [typing, setTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, typing]);

  const handleSend = useCallback((content: string) => {
    // Free plan: limit to 10 messages per day
    if (!isPro) {
      const today = new Date().toDateString();
      const key = `aurelix_msgs_${today}`;
      const count = parseInt(localStorage.getItem(key) || "0", 10);
      if (count >= 10) {
        toast.error("Daily message limit reached. Upgrade to Pro for unlimited chat.");
        navigate("/upgrade");
        return;
      }
      localStorage.setItem(key, (count + 1).toString());
    }

    const userMsg: Message = { id: Date.now().toString(), role: "user", content, model };
    setMessages((prev) => [...prev, userMsg]);
    setTyping(true);

    // Build chat history for context
    const chatHistory: ChatMessage[] = messages.map((m) => ({
      role: m.role,
      content: m.content,
    }));
    chatHistory.push({ role: "user", content });

    let assistantContent = "";
    const assistantId = (Date.now() + 1).toString();

    streamChat({
      messages: chatHistory,
      model,
      onDelta: (chunk) => {
        assistantContent += chunk;
        setTyping(false);
        setMessages((prev) => {
          const last = prev[prev.length - 1];
          if (last?.role === "assistant" && last.id === assistantId) {
            return prev.map((m) =>
              m.id === assistantId ? { ...m, content: assistantContent } : m
            );
          }
          return [
            ...prev,
            { id: assistantId, role: "assistant", content: assistantContent, model },
          ];
        });
      },
      onDone: () => {
        setTyping(false);
      },
      onError: (error) => {
        setTyping(false);
        toast.error(error);
      },
    });
  }, [model, isPro, navigate, messages]);

  const toggleSave = useCallback((id: string) => {
    setMessages((prev) => prev.map((m) => (m.id === id ? { ...m, saved: !m.saved } : m)));
  }, []);

  const copyMessage = useCallback((id: string, content: string) => {
    navigator.clipboard.writeText(content);
    setMessages((prev) => prev.map((m) => (m.id === id ? { ...m, copied: true } : m)));
    setTimeout(() => {
      setMessages((prev) => prev.map((m) => (m.id === id ? { ...m, copied: false } : m)));
    }, 2000);
  }, []);

  const isEmpty = messages.length === 0;

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <header className="flex items-center justify-between px-4 pt-3 pb-2">
        <button onClick={openSidebar} className="h-9 w-9 rounded-xl glass flex items-center justify-center">
          <Menu className="h-4 w-4 text-muted-foreground" />
        </button>

        <div className="flex items-center gap-0.5 rounded-full border border-border bg-muted p-0.5">
          {(["gemini", "chatgpt"] as const).map((m) => (
            <button
              key={m}
              onClick={() => setModel(m)}
              className={`relative px-4 py-1.5 text-xs font-medium rounded-full transition-colors ${
                model === m ? "text-primary-foreground" : "text-muted-foreground"
              }`}
            >
              {model === m && (
                <motion.div
                  layoutId="model-switch"
                  className="absolute inset-0 rounded-full bg-foreground"
                  transition={{ type: "spring", stiffness: 500, damping: 35 }}
                />
              )}
              <span className="relative z-10">{m === "chatgpt" ? "GPT" : "Gemini"}</span>
            </button>
          ))}
        </div>

        <div className="h-9 w-9" />
      </header>

      {/* Messages or Welcome */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto px-4 py-2">
        {isEmpty ? (
          <div className="flex flex-col items-center justify-center h-full gap-6 animate-fade-in">
            <div className="relative">
              <div className="h-14 w-14 rounded-2xl bg-accent flex items-center justify-center">
                <Sparkles className="h-7 w-7 text-foreground" />
              </div>
            </div>
            <div className="text-center space-y-1">
              <h2 className="font-display text-xl font-bold text-foreground">What can I help you with?</h2>
              <p className="text-sm text-muted-foreground">Start a conversation or try a suggestion</p>
            </div>
            <div className="grid grid-cols-2 gap-2 w-full max-w-sm">
              {suggestions.map((s, i) => (
                <motion.button
                  key={s.label}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.05 + i * 0.06 }}
                  onClick={() => handleSend(s.prompt)}
                  className="flex items-start gap-2.5 p-3 rounded-xl border border-border bg-card hover:bg-accent transition-colors text-left"
                >
                  <s.icon className="h-4 w-4 text-muted-foreground mt-0.5 shrink-0" />
                  <span className="text-xs text-foreground leading-snug">{s.label}</span>
                </motion.button>
              ))}
            </div>
          </div>
        ) : (
          <div className="space-y-3">
            {messages.map((msg) => (
              <motion.div
                key={msg.id}
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.15 }}
                className={`flex gap-2 ${msg.role === "user" ? "justify-end" : "justify-start"}`}
              >
                {msg.role === "assistant" && (
                  <div className="h-7 w-7 rounded-lg bg-accent flex items-center justify-center shrink-0 mt-1">
                    <Bot className="h-3.5 w-3.5 text-foreground" />
                  </div>
                )}
                <div className="max-w-[78%] space-y-1">
                  <div
                    className={`rounded-2xl px-4 py-2.5 text-sm leading-relaxed ${
                      msg.role === "user"
                        ? "bg-foreground text-background rounded-br-md"
                        : "bg-card border border-border rounded-bl-md text-foreground"
                    }`}
                  >
                    {msg.content}
                  </div>
                  {msg.role === "assistant" && (
                    <div className="flex items-center gap-1 pl-1">
                      <button
                        onClick={() => copyMessage(msg.id, msg.content)}
                        className="h-6 w-6 rounded-md flex items-center justify-center hover:bg-accent transition-colors"
                      >
                        {msg.copied ? (
                          <Check className="h-3 w-3 text-muted-foreground" />
                        ) : (
                          <Copy className="h-3 w-3 text-muted-foreground" />
                        )}
                      </button>
                      <button
                        onClick={() => toggleSave(msg.id)}
                        className="h-6 w-6 rounded-md flex items-center justify-center hover:bg-accent transition-colors"
                      >
                        <Bookmark
                          className={`h-3 w-3 ${msg.saved ? "text-foreground fill-foreground" : "text-muted-foreground"}`}
                        />
                      </button>
                    </div>
                  )}
                </div>
                {msg.role === "user" && (
                  <div className="h-7 w-7 rounded-lg bg-foreground flex items-center justify-center shrink-0 mt-1">
                    <User className="h-3.5 w-3.5 text-background" />
                  </div>
                )}
              </motion.div>
            ))}
            {typing && (
              <div className="flex gap-2">
                <div className="h-7 w-7 rounded-lg bg-accent flex items-center justify-center shrink-0">
                  <Bot className="h-3.5 w-3.5 text-foreground" />
                </div>
                <TypingIndicator />
              </div>
            )}
          </div>
        )}
      </div>

      <ChatInput onSend={handleSend} placeholder={`Message ${model === "gemini" ? "Gemini" : "ChatGPT"}...`} />
    </div>
  );
}
