import { useState } from "react";
import { ChatInput } from "@/components/ChatInput";
import { motion } from "framer-motion";
import { Play, Pause, Download, Volume2, Copy, Check } from "lucide-react";
import { UpgradeGate } from "@/components/UpgradeGate";

const voiceOptions = [
  { id: "narrator", label: "Narrator", desc: "Deep & authoritative" },
  { id: "casual", label: "Casual", desc: "Friendly & warm" },
  { id: "energetic", label: "Energetic", desc: "Upbeat & dynamic" },
  { id: "calm", label: "Calm", desc: "Soothing & gentle" },
];

interface AudioClip {
  id: string;
  text: string;
  voice: string;
  playing: boolean;
  copied?: boolean;
}

export default function VoiceScreen() {
  const [selectedVoice, setSelectedVoice] = useState("narrator");
  const [clips, setClips] = useState<AudioClip[]>([]);

  const handleGenerate = (text: string) => {
    setClips((prev) => [
      ...prev,
      { id: Date.now().toString(), text, voice: selectedVoice, playing: false },
    ]);
  };

  const togglePlay = (id: string) => {
    setClips((prev) => prev.map((c) => (c.id === id ? { ...c, playing: !c.playing } : c)));
  };

  const copyClip = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setClips((prev) => prev.map((c) => (c.id === id ? { ...c, copied: true } : c)));
    setTimeout(() => {
      setClips((prev) => prev.map((c) => (c.id === id ? { ...c, copied: false } : c)));
    }, 2000);
  };

  return (
    <UpgradeGate feature="Voice AI">
      <div className="flex flex-col h-full">
        <header className="px-4 pt-4 pb-2">
          <h1 className="font-display text-lg font-bold text-foreground">Voice Studio</h1>
          <p className="text-xs text-muted-foreground">Text-to-speech for creators</p>
        </header>

        <div className="flex-1 overflow-y-auto px-4 py-2 space-y-4">
          <div className="space-y-2">
            <p className="text-[10px] text-muted-foreground font-medium uppercase tracking-widest">Voice Style</p>
            <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar">
              {voiceOptions.map((voice) => (
                <button
                  key={voice.id}
                  onClick={() => setSelectedVoice(voice.id)}
                  className={`shrink-0 px-4 py-3 rounded-xl text-left transition-all border ${
                    selectedVoice === voice.id
                      ? "border-foreground/30 bg-accent"
                      : "border-border bg-card"
                  }`}
                >
                  <p className={`text-sm font-medium ${selectedVoice === voice.id ? "text-foreground" : "text-secondary-foreground"}`}>
                    {voice.label}
                  </p>
                  <p className="text-[10px] text-muted-foreground">{voice.desc}</p>
                </button>
              ))}
            </div>
          </div>

          {clips.length === 0 && (
            <div className="flex flex-col items-center justify-center py-14 gap-4 opacity-40 animate-fade-in">
              <Volume2 className="h-10 w-10 text-foreground" />
              <p className="text-sm text-muted-foreground">Enter text to generate speech</p>
            </div>
          )}

          <div className="space-y-2">
            {clips.map((clip) => (
              <motion.div
                key={clip.id}
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.15 }}
                className="flex items-center gap-3 p-3 rounded-xl border border-border bg-card"
              >
                <button
                  onClick={() => togglePlay(clip.id)}
                  className="h-10 w-10 shrink-0 rounded-xl bg-accent flex items-center justify-center"
                >
                  {clip.playing ? (
                    <Pause className="h-4 w-4 text-foreground" />
                  ) : (
                    <Play className="h-4 w-4 text-foreground ml-0.5" />
                  )}
                </button>
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-foreground truncate">{clip.text}</p>
                  <p className="text-[10px] text-muted-foreground capitalize">{clip.voice} voice</p>
                </div>
                <div className="flex gap-1">
                  <button
                    onClick={() => copyClip(clip.id, clip.text)}
                    className="h-8 w-8 rounded-lg bg-accent flex items-center justify-center"
                  >
                    {clip.copied ? <Check className="h-3.5 w-3.5 text-foreground" /> : <Copy className="h-3.5 w-3.5 text-muted-foreground" />}
                  </button>
                  <button className="h-8 w-8 rounded-lg bg-accent flex items-center justify-center">
                    <Download className="h-3.5 w-3.5 text-muted-foreground" />
                  </button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        <ChatInput onSend={handleGenerate} placeholder="Type text to convert to speech..." />
      </div>
    </UpgradeGate>
  );
}
