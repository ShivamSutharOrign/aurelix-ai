import { useState, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  MessageSquare, Image, Video, Mic, Zap, Shield, Check, X,
  Crown, ArrowLeft, Copy, CheckCircle2, ExternalLink, Search
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { usePlan } from "@/contexts/PlanContext";

const freeBenefits = [
  { text: "10 AI messages/day", included: true },
  { text: "Basic chat features", included: true },
  { text: "Research & Summaries", included: false },
  { text: "Image generation", included: false },
  { text: "Video generation", included: false },
  { text: "Voice AI & Audio", included: false },
  { text: "Priority access", included: false },
];

const proBenefits = [
  { icon: MessageSquare, text: "Unlimited AI Chat (ChatGPT & Gemini)" },
  { icon: Search, text: "Research & Summaries (Perplexity style)" },
  { icon: Image, text: "Image Generator (thumbnails)" },
  { icon: Video, text: "Video Generator" },
  { icon: Mic, text: "AI Voice & Audio tools" },
  { icon: Zap, text: "Faster response speed" },
  { icon: Shield, text: "No limits & priority access" },
];

const UPI_ID_PRIMARY = "ytshivam@fam";
const UPI_ID_ALT = "8963086401@fam";
const UPI_LINK = `upi://pay?pa=${UPI_ID_PRIMARY}&pn=AurelixAI&am=199&cu=INR`;

type Step = "plans" | "payment" | "transaction" | "success";

export default function UpgradeScreen() {
  const navigate = useNavigate();
  const { submitTransaction, pendingVerification } = usePlan();
  const [step, setStep] = useState<Step>(pendingVerification ? "success" : "plans");
  const [transactionId, setTransactionId] = useState("");
  const [copied, setCopied] = useState<string | null>(null);

  const copyUpi = useCallback((id: string) => {
    navigator.clipboard.writeText(id);
    setCopied(id);
    toast.success("UPI ID copied!");
    setTimeout(() => setCopied(null), 2000);
  }, []);

  const handleSubmitTransaction = useCallback(() => {
    if (transactionId.trim().length < 4) {
      toast.error("Please enter a valid Transaction ID");
      return;
    }
    submitTransaction(transactionId.trim());
    setStep("success");
    toast.success("Transaction submitted for verification!");
  }, [transactionId, submitTransaction]);

  return (
    <div className="flex flex-col h-full bg-background">
      <div className="flex items-center gap-3 px-4 pt-4 pb-2">
        <button
          onClick={() => step === "plans" ? navigate(-1) : setStep("plans")}
          className="p-2 rounded-full hover:bg-secondary transition-colors"
        >
          <ArrowLeft className="h-5 w-5 text-foreground" />
        </button>
        <h1 className="font-display text-lg font-semibold text-foreground">
          {step === "success" ? "Payment Submitted" : "Upgrade to Pro"}
        </h1>
      </div>

      <div className="flex-1 overflow-y-auto no-scrollbar px-4 pb-8">
        <AnimatePresence mode="wait">
          {step === "plans" && (
            <motion.div
              key="plans"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.2 }}
              className="space-y-5 pt-2"
            >
              <p className="text-muted-foreground text-sm text-center">
                Unlock the full power of Aurelix AI
              </p>

              {/* Free Plan */}
              <div className="rounded-2xl border border-border bg-card p-5 space-y-4">
                <div className="flex items-center justify-between">
                  <h2 className="font-display text-base font-semibold text-foreground">Free</h2>
                  <span className="text-xs text-muted-foreground bg-secondary px-2.5 py-1 rounded-full">Current</span>
                </div>
                <p className="text-2xl font-display font-bold text-foreground">
                  ₹0<span className="text-sm font-normal text-muted-foreground">/month</span>
                </p>
                <div className="space-y-2.5">
                  {freeBenefits.map((b) => (
                    <div key={b.text} className="flex items-center gap-2.5 text-sm">
                      {b.included ? (
                        <Check className="h-4 w-4 text-foreground shrink-0" />
                      ) : (
                        <X className="h-4 w-4 text-muted-foreground/40 shrink-0" />
                      )}
                      <span className={b.included ? "text-foreground" : "text-muted-foreground/50"}>
                        {b.text}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Pro Plan */}
              <div className="relative rounded-2xl border border-foreground/20 bg-card p-5 space-y-4 glow">
                <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                  <span className="bg-foreground text-background text-[10px] font-semibold px-3 py-1 rounded-full flex items-center gap-1">
                    <Crown className="h-3 w-3" /> RECOMMENDED
                  </span>
                </div>
                <div className="flex items-center justify-between pt-1">
                  <h2 className="font-display text-base font-semibold text-foreground">Pro</h2>
                  <Zap className="h-4 w-4 text-foreground" />
                </div>
                <p className="text-2xl font-display font-bold text-foreground">
                  ₹199<span className="text-sm font-normal text-muted-foreground">/month</span>
                </p>
                <div className="space-y-2.5">
                  {proBenefits.map((b) => (
                    <div key={b.text} className="flex items-center gap-2.5 text-sm">
                      <b.icon className="h-4 w-4 text-foreground shrink-0" />
                      <span className="text-foreground">{b.text}</span>
                    </div>
                  ))}
                </div>
                <button
                  onClick={() => setStep("payment")}
                  className="w-full py-3 rounded-xl bg-foreground text-background font-semibold text-sm transition-transform active:scale-[0.98]"
                >
                  Upgrade to Pro — ₹199/mo
                </button>
              </div>
            </motion.div>
          )}

          {step === "payment" && (
            <motion.div
              key="payment"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.2 }}
              className="space-y-5 pt-2"
            >
              <div className="text-center space-y-1">
                <h2 className="font-display text-lg font-semibold text-foreground">Pay using UPI</h2>
                <p className="text-muted-foreground text-sm">Pay using any UPI app (FamPay, GPay, PhonePe)</p>
              </div>

              {/* Pay Now button with UPI deep link */}
              <a
                href={UPI_LINK}
                className="w-full py-3 rounded-xl bg-foreground text-background font-semibold text-sm transition-transform active:scale-[0.98] flex items-center justify-center gap-2"
              >
                <ExternalLink className="h-4 w-4" />
                Pay Now — ₹199
              </a>

              <div className="flex items-center gap-3">
                <div className="flex-1 h-px bg-border" />
                <span className="text-xs text-muted-foreground">or pay manually</span>
                <div className="flex-1 h-px bg-border" />
              </div>

              {/* UPI IDs */}
              <div className="space-y-2.5">
                {[UPI_ID_PRIMARY, UPI_ID_ALT].map((id) => (
                  <div
                    key={id}
                    className="flex items-center justify-between px-4 py-3 rounded-xl border border-border bg-card"
                  >
                    <span className="text-sm font-mono text-foreground">{id}</span>
                    <button
                      onClick={() => copyUpi(id)}
                      className="p-1.5 rounded-lg hover:bg-secondary transition-colors"
                    >
                      {copied === id ? (
                        <CheckCircle2 className="h-4 w-4 text-foreground" />
                      ) : (
                        <Copy className="h-4 w-4 text-muted-foreground" />
                      )}
                    </button>
                  </div>
                ))}
              </div>

              <div className="flex items-center justify-center gap-1.5 text-muted-foreground text-xs">
                <Shield className="h-3.5 w-3.5" />
                <span>Secure Payment · 100% Safe</span>
              </div>

              <button
                onClick={() => setStep("transaction")}
                className="w-full py-3 rounded-xl border border-border bg-card text-foreground font-semibold text-sm transition-transform active:scale-[0.98]"
              >
                I Have Paid
              </button>
            </motion.div>
          )}

          {step === "transaction" && (
            <motion.div
              key="transaction"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.2 }}
              className="space-y-5 pt-6"
            >
              <div className="text-center space-y-1">
                <h2 className="font-display text-lg font-semibold text-foreground">Enter Transaction ID</h2>
                <p className="text-muted-foreground text-sm">Paste the UPI transaction/reference ID</p>
              </div>

              <input
                type="text"
                value={transactionId}
                onChange={(e) => setTransactionId(e.target.value)}
                placeholder="e.g. 412345678901"
                className="w-full px-4 py-3 rounded-xl border border-border bg-card text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-foreground/30"
              />

              <button
                onClick={handleSubmitTransaction}
                className="w-full py-3 rounded-xl bg-foreground text-background font-semibold text-sm transition-transform active:scale-[0.98]"
              >
                Submit for Verification
              </button>
            </motion.div>
          )}

          {step === "success" && (
            <motion.div
              key="success"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.3 }}
              className="flex flex-col items-center justify-center pt-16 space-y-5 text-center"
            >
              <div className="w-16 h-16 rounded-full bg-foreground/10 flex items-center justify-center">
                <CheckCircle2 className="h-8 w-8 text-foreground" />
              </div>
              <div className="space-y-2">
                <h2 className="font-display text-xl font-bold text-foreground">Payment Under Verification</h2>
                <p className="text-muted-foreground text-sm max-w-[280px]">
                  Your Pro plan will be activated after verification. Activation within 5–10 minutes.
                </p>
              </div>
              <p className="text-xs text-muted-foreground">Contact on WhatsApp if any issue</p>
              <button
                onClick={() => navigate("/")}
                className="mt-4 px-6 py-3 rounded-xl bg-foreground text-background font-semibold text-sm transition-transform active:scale-[0.98]"
              >
                Back to Chat
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
