import { useState, useRef, useEffect } from "react";
import { ChatInput } from "@/components/ChatInput";
import { TypingIndicator } from "@/components/TypingIndicator";
import { motion } from "framer-motion";
import { Globe, FileText, Link2, BookOpen, Bot, Copy, Check } from "lucide-react";

const quickActions = [
  { icon: Globe, label: "Web Search", desc: "Search the web with AI" },
  { icon: FileText, label: "Summarize", desc: "Condense any text" },
  { icon: Link2, label: "URL Summary", desc: "Analyze any link" },
  { icon: BookOpen, label: "PDF Analysis", desc: "Extract insights" },
];

interface Result {
  id: string;
  query: string;
  summary: string;
  sources: string[];
  copied?: boolean;
}

export default function ResearchScreen() {
  const [results, setResults] = useState<Result[]>([]);
  const [typing, setTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [results, typing]);

  const handleSearch = (query: string) => {
    setTyping(true);
    setTimeout(() => {
      setTyping(false);
      setResults((prev) => [
        ...prev,
        {
          id: Date.now().toString(),
          query,
          summary:
            "Based on multiple sources, here's what I found: This is a demo research result. Enable Lovable Cloud to connect real AI-powered research with web sources, citations, and deep analysis capabilities.",
          sources: ["wikipedia.org", "arxiv.org", "docs.dev", "research.io"],
        },
      ]);
    }, 2000);
  };

  const copyResult = (id: string, content: string) => {
    navigator.clipboard.writeText(content);
    setResults((prev) => prev.map((r) => (r.id === id ? { ...r, copied: true } : r)));
    setTimeout(() => {
      setResults((prev) => prev.map((r) => (r.id === id ? { ...r, copied: false } : r)));
    }, 2000);
  };

  return (
    <div className="flex flex-col h-full">
      <header className="px-4 pt-4 pb-2">
        <h1 className="font-display text-lg font-bold text-foreground">Research</h1>
        <p className="text-xs text-muted-foreground">AI-powered search & summaries</p>
      </header>

      <div ref={scrollRef} className="flex-1 overflow-y-auto px-4 py-2">
        {results.length === 0 && !typing && (
          <div className="space-y-4 animate-fade-in">
            <div className="grid grid-cols-2 gap-2">
              {quickActions.map((action, i) => (
                <motion.button
                  key={action.label}
                  initial={{ opacity: 0, scale: 0.97 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: i * 0.04 }}
                  onClick={() => handleSearch(action.label)}
                  className="flex flex-col items-start gap-2 p-4 rounded-xl border border-border bg-card hover:bg-accent transition-colors"
                >
                  <div className="h-9 w-9 rounded-lg bg-accent flex items-center justify-center">
                    <action.icon className="h-4 w-4 text-foreground" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-foreground">{action.label}</p>
                    <p className="text-[10px] text-muted-foreground">{action.desc}</p>
                  </div>
                </motion.button>
              ))}
            </div>
          </div>
        )}

        <div className="space-y-3">
          {results.map((result) => (
            <motion.div
              key={result.id}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.15 }}
              className="space-y-2"
            >
              <div className="flex items-center gap-2 text-xs text-muted-foreground font-medium">
                <Globe className="h-3.5 w-3.5" />
                {result.query}
              </div>
              <div className="rounded-xl border border-border bg-card p-4 space-y-3">
                <div className="flex items-start gap-2">
                  <Bot className="h-4 w-4 text-foreground mt-0.5 shrink-0" />
                  <p className="text-sm text-foreground leading-relaxed">{result.summary}</p>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {result.sources.map((s) => (
                    <span key={s} className="text-[10px] px-2 py-0.5 rounded-full bg-accent text-muted-foreground">
                      {s}
                    </span>
                  ))}
                </div>
                <button
                  onClick={() => copyResult(result.id, result.summary)}
                  className="flex items-center gap-1 text-[10px] text-muted-foreground hover:text-foreground transition-colors"
                >
                  {result.copied ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
                  {result.copied ? "Copied" : "Copy"}
                </button>
              </div>
            </motion.div>
          ))}
          {typing && (
            <div className="flex gap-2 items-start">
              <Bot className="h-4 w-4 text-foreground mt-2 shrink-0" />
              <TypingIndicator />
            </div>
          )}
        </div>
      </div>

      <ChatInput onSend={handleSearch} placeholder="Research any topic..." />
    </div>
  );
}
