import { useState } from "react";
import { ChatInput } from "@/components/ChatInput";
import { motion } from "framer-motion";
import { Download, Copy, Wand2, ImageIcon } from "lucide-react";
import { UpgradeGate } from "@/components/UpgradeGate";

const promptTemplates = [
  { emoji: "🎬", text: "YouTube thumbnail: excited face with bold text" },
  { emoji: "🌄", text: "Cinematic landscape for travel vlog banner" },
  { emoji: "✨", text: "Minimalist logo for tech channel" },
  { emoji: "🎙️", text: "Eye-catching podcast cover art" },
  { emoji: "📦", text: "Product mockup on gradient background" },
  { emoji: "🎮", text: "Anime-style character for gaming channel" },
];

interface GeneratedImage {
  id: string;
  prompt: string;
}

export default function ImageScreen() {
  const [images, setImages] = useState<GeneratedImage[]>([]);

  const handleGenerate = (prompt: string) => {
    setImages((prev) => [...prev, { id: Date.now().toString(), prompt }]);
  };

  return (
    <UpgradeGate feature="Image Generator">
      <div className="flex flex-col h-full">
        <header className="px-4 pt-4 pb-2">
          <h1 className="font-display text-lg font-bold text-foreground">Image Studio</h1>
          <p className="text-xs text-muted-foreground">AI-generated visuals for creators</p>
        </header>

        <div className="flex-1 overflow-y-auto px-4 py-2">
          {images.length === 0 ? (
            <div className="space-y-4 animate-fade-in">
              <p className="text-[10px] text-muted-foreground font-medium uppercase tracking-widest">Creator Templates</p>
              <div className="space-y-2">
                {promptTemplates.map((t, i) => (
                  <motion.button
                    key={t.text}
                    initial={{ opacity: 0, x: -6 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.04 }}
                    onClick={() => handleGenerate(t.text)}
                    className="w-full flex items-center gap-3 p-3.5 rounded-xl border border-border bg-card hover:bg-accent transition-colors text-left"
                  >
                    <span className="text-lg">{t.emoji}</span>
                    <span className="text-sm text-foreground">{t.text}</span>
                    <Wand2 className="h-3.5 w-3.5 text-muted-foreground ml-auto shrink-0" />
                  </motion.button>
                ))}
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-3">
              {images.map((img) => (
                <motion.div
                  key={img.id}
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.15 }}
                  className="relative aspect-square rounded-2xl overflow-hidden group border border-border"
                >
                  <div className="absolute inset-0 bg-gradient-to-br from-accent via-muted to-card" />
                  <div className="absolute inset-0 flex items-center justify-center p-3">
                    <div className="text-center space-y-2">
                      <ImageIcon className="h-6 w-6 text-muted-foreground mx-auto" />
                      <p className="text-[10px] text-muted-foreground leading-tight">{img.prompt}</p>
                    </div>
                  </div>
                  <div className="absolute bottom-0 inset-x-0 flex justify-center gap-2 p-2 bg-gradient-to-t from-background/90 to-transparent translate-y-full group-hover:translate-y-0 transition-transform">
                    <button className="h-8 w-8 rounded-lg bg-card border border-border flex items-center justify-center">
                      <Download className="h-3.5 w-3.5 text-foreground" />
                    </button>
                    <button className="h-8 w-8 rounded-lg bg-card border border-border flex items-center justify-center">
                      <Copy className="h-3.5 w-3.5 text-foreground" />
                    </button>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </div>

        <ChatInput onSend={handleGenerate} placeholder="Describe your image..." />
      </div>
    </UpgradeGate>
  );
}
