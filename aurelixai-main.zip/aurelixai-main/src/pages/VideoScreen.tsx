import { useState } from "react";
import { ChatInput } from "@/components/ChatInput";
import { motion } from "framer-motion";
import { Play, Clock, FileVideo, Clapperboard, Download } from "lucide-react";
import { UpgradeGate } from "@/components/UpgradeGate";

interface VideoJob {
  id: string;
  script: string;
  status: "generating" | "done";
}

export default function VideoScreen() {
  const [jobs, setJobs] = useState<VideoJob[]>([]);

  const handleGenerate = (script: string) => {
    const job: VideoJob = { id: Date.now().toString(), script, status: "generating" };
    setJobs((prev) => [...prev, job]);
    setTimeout(() => {
      setJobs((prev) => prev.map((j) => (j.id === job.id ? { ...j, status: "done" } : j)));
    }, 3000);
  };

  return (
    <UpgradeGate feature="Video Generator">
      <div className="flex flex-col h-full">
        <header className="px-4 pt-4 pb-2">
          <h1 className="font-display text-lg font-bold text-foreground">Video Studio</h1>
          <p className="text-xs text-muted-foreground">Script → Short Video</p>
        </header>

        <div className="flex-1 overflow-y-auto px-4 py-2">
          {jobs.length === 0 && (
            <div className="flex flex-col items-center justify-center h-full gap-5 animate-fade-in">
              <div className="h-20 w-20 rounded-2xl bg-accent flex items-center justify-center">
                <Clapperboard className="h-10 w-10 text-foreground" />
              </div>
              <div className="text-center space-y-2">
                <p className="font-display text-lg font-bold text-foreground">Create AI Videos</p>
                <p className="text-xs text-muted-foreground max-w-[260px] leading-relaxed">
                  Paste a script and generate a short video. Perfect for YouTube Shorts, Reels & TikToks.
                </p>
              </div>
            </div>
          )}

          <div className="space-y-3">
            {jobs.map((job) => (
              <motion.div
                key={job.id}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.15 }}
                className="rounded-xl border border-border bg-card p-4 space-y-3"
              >
                <p className="text-sm text-foreground line-clamp-2">{job.script}</p>
                {job.status === "generating" ? (
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <Clock className="h-3.5 w-3.5 animate-spin" />
                    <span>Generating video...</span>
                    <div className="flex-1 h-1 rounded-full bg-muted overflow-hidden">
                      <div className="h-full w-1/2 rounded-full bg-foreground/30 animate-shimmer bg-[length:200%_100%]" />
                    </div>
                  </div>
                ) : (
                  <div className="relative aspect-video rounded-xl bg-muted flex items-center justify-center overflow-hidden border border-border">
                    <div className="h-12 w-12 rounded-full bg-card border border-border flex items-center justify-center">
                      <Play className="h-5 w-5 text-foreground ml-0.5" />
                    </div>
                    <div className="absolute bottom-2 right-2 flex gap-1.5">
                      <span className="text-[10px] bg-card border border-border px-2 py-0.5 rounded-md text-muted-foreground flex items-center gap-1">
                        <FileVideo className="h-3 w-3" /> Demo
                      </span>
                      <button className="bg-card border border-border px-2 py-0.5 rounded-md">
                        <Download className="h-3 w-3 text-foreground" />
                      </button>
                    </div>
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        </div>

        <ChatInput onSend={handleGenerate} placeholder="Paste your script here..." />
      </div>
    </UpgradeGate>
  );
}
