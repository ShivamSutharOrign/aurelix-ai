import { createContext, useContext, useState, useEffect, useCallback, ReactNode } from "react";

type Plan = "free" | "pro";

interface PlanContextType {
  plan: Plan;
  setPlan: (plan: Plan) => void;
  isPro: boolean;
  pendingVerification: boolean;
  submitTransaction: (txId: string) => void;
}

const PlanContext = createContext<PlanContextType | null>(null);

export function PlanProvider({ children }: { children: ReactNode }) {
  const [plan, setPlanState] = useState<Plan>(() => {
    return (localStorage.getItem("aurelix_plan") as Plan) || "free";
  });
  const [pendingVerification, setPending] = useState(() => {
    return localStorage.getItem("aurelix_pending_tx") !== null;
  });

  const setPlan = useCallback((p: Plan) => {
    setPlanState(p);
    localStorage.setItem("aurelix_plan", p);
  }, []);

  const submitTransaction = useCallback((txId: string) => {
    const data = { txId, date: new Date().toISOString(), status: "pending" };
    localStorage.setItem("aurelix_pending_tx", JSON.stringify(data));
    const history = JSON.parse(localStorage.getItem("aurelix_tx_history") || "[]");
    history.push(data);
    localStorage.setItem("aurelix_tx_history", JSON.stringify(history));
    setPending(true);
  }, []);

  useEffect(() => {
    const stored = localStorage.getItem("aurelix_plan") as Plan;
    if (stored) setPlanState(stored);
  }, []);

  return (
    <PlanContext.Provider value={{ plan, setPlan, isPro: plan === "pro", pendingVerification, submitTransaction }}>
      {children}
    </PlanContext.Provider>
  );
}

export function usePlan() {
  const ctx = useContext(PlanContext);
  if (!ctx) throw new Error("usePlan must be inside PlanProvider");
  return ctx;
}
